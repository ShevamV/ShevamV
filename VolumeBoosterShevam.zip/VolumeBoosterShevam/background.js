//background.js

chrome.runtime.onInstalled.addListener(() => {
  console.log("Heya! ShevamV's Volume Booster has Installed...🎉🥳");
});